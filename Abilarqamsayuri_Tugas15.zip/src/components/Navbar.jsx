import styled from 'styled-components'


function Navbar(){
let tittle = "Day One Profil Sederhana One Day Profil Senior"

let TextHeader = styled.h2`
    text-align: center;
    background-color: darkblue;
    padding: 50px;
    margin-bottom: 40px;
    color: white;
`

return(
    <div>
        <TextHeader>{tittle}</TextHeader>
    </div>
)

}

export default Navbar