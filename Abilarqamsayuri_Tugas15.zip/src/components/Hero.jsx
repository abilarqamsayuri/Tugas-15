import styled from 'styled-components'


function Hero(){

    let TextTittel = styled.h5`
    color: darkgrey;
    `

    let TextTittel2 = styled.h3`
    color: whitesmoke;
    `

    const title = [
        'nama lengkap',
        'asal',
        'umur',
        'status',
    ]

    const user = [
        'Abil Arqam Sayuri',
        'Boltim Sulawesi Utara',
        '18 tahun',
        'Mahasantri',
    ]

    return (
        <>
            <div>
                <TextTittel>{title[0]}</TextTittel>
                <TextTittel2>{user[0]}</TextTittel2> <br />

                <TextTittel>{title[1]}</TextTittel>
                <TextTittel2>{user[1]}</TextTittel2> <br />

                <TextTittel>{title[2]}</TextTittel>
                <TextTittel2>{user[2]}</TextTittel2> <br />

                <TextTittel>{title[3]}</TextTittel>
                <TextTittel2>{user[3]}</TextTittel2> <br />

            </div>
        </>
    )
}

export default Hero