import styled from 'styled-components'

function Footer(){

    const Tagline = styled.div`
        background-color: darkblue;
        padding: 5px;
    `

    const TextTagline = styled.p`
        color: white;
        font-size: 0.8rem;
    `

    return(
        <>
           <Tagline>
                <TextTagline>Copyright By Kita pasti Bisa</TextTagline>
           </Tagline> 
        </>
    )
}

export default Footer